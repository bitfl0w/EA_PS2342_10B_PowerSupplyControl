﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO.Ports;
using System.Management;
using NS_Device_EA_PS_2342_10B;

namespace EA_PS_2342_1B_Control
{
    public partial class ControlForm : Form
    {
        public static SerialPort mySerialPort { get; set; }
        Device_EA_PS_2342_10B psuDev;

        public ControlForm()
        {
            InitializeComponent();
            getSerialPortInformation();

            // set nodeIds of the gui elements
            outputNode1.setNodeId(1);
            outputNode2.setNodeId(2);
            MaximizeBox = false;
        }

        void getSerialPortInformation()
        {
            comboBox_comPort.Items.Clear();
            using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
            {
                var portnames = SerialPort.GetPortNames();
                var ports = searcher.Get().Cast<ManagementBaseObject>().ToList().Select(p => p["Caption"].ToString());

                var portList = portnames.Select(n => n + " - " + ports.FirstOrDefault(s => s.Contains(n))).ToList();
                
                foreach (string s in portList)
                {
                    int index = s.LastIndexOf(@"(COM");
                    comboBox_comPort.Items.Add(s.Substring(0, index));
                }
            }
        }

        private void button_createComPort_Click(object sender, EventArgs e)
        {
            createComPort();
        }

        private void createComPort()
        {
            if (comboBox_comPort.SelectedItem.ToString() != String.Empty)
            {
                string portName = comboBox_comPort.SelectedItem.ToString().Split(' ')[0];
                mySerialPort = new SerialPort(portName, 115200, Parity.Odd, 8, StopBits.One);
                try
                {
                    mySerialPort.Open();

                    psuDev = new Device_EA_PS_2342_10B(mySerialPort);
                    outputNode1.addPsDevice(psuDev);
                    outputNode2.addPsDevice(psuDev);

                    button_createComPort.Text = "connected";
                    button_createComPort.Enabled = false;
                    outputNode1.Enabled = true;
                    outputNode2.Enabled = true;
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message, "Failed to open specified COM Port", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                MessageBox.Show("Select a COM Port first", "Failed to open specified COM Port", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void button_refreshComPorts_Click(object sender, EventArgs e)
        {
            comboBox_comPort.Items.Clear();
            getSerialPortInformation();
        }

        private void button_dbg_Click(object sender, EventArgs e)
        {
            Device_EA_PS_2342_10B psNode = new Device_EA_PS_2342_10B(new SerialPort());
            psNode.activateOutput(1);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeApplication();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.Show();
        }

        private void closeApplication()
        {
            if (mySerialPort != null && mySerialPort.IsOpen)
            {
                outputNode1.setControlToManual();
                outputNode2.setControlToManual();
                mySerialPort.Close();
            }
            Application.Exit();
        }

        private void ControlForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            closeApplication();
        }

        private void comboBox_comPort_DropDown(object sender, EventArgs e)
        {
            getSerialPortInformation();
        }

        private void connectivityIssuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicking on the combobox with the com ports automatically refreshes all com ports. If the port does not show up, make sure that:\n" +
                            " - The device is properly connected.\n" +
                            " - The driver for the PSU is installed (must be done manually).\n\n" +
                            "Sometimes just unplugging and plugging in the cable again makes the com port appear.",
                            "How to resolve connectivity issues",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private void comboBox_comPort_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                createComPort();
                e.Handled = e.SuppressKeyPress = true;  // surpress sound generated by keypress (enter)
            }
        }

        private void outputNode1_Load(object sender, EventArgs e)
        {

        }
    }
}
