Note about USB driver for Windows

Compatible with following Windows versions:
- Windows XP 32bit, Home + Professional
- Windows Vista 32bit
- Windows Server 2008
- Windows 7, 32bit + 64bit, Home + Professional + Ultimate
- Windows 7 Embedded, 32bit + 64bit
- Windows 8
- Windows 10

Compatible with following device series:
- ELR 9000
- PSI 9000 2U/3U
- PS 9000 1U/2U/3U
- PS 5000
- PSI 5000

(c) 2015, Elektro-Automatik 